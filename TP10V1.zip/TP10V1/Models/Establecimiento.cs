using System;

namespace TP10.Models
{
    public class Establecimiento
    {
        private int _IdEstablecimiento;
        private string _ENombre;
        private string _Direccion;
        private string _Localidad;


        public int IdEstablecimiento {get; set;}
        public string ENombre {get; set;}
        public string Direccion {get; set;}
        public string Localidad {get; set;}
        
    }
}