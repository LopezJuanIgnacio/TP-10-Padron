using System;
using System.Data.SqlClient;
using TP10.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Dapper;

namespace TP10.Models
{
    public static class BD
    {
        private static string _connectionString = @"Server=DESKTOP-D44S535\SQLEXPRESS;DataBase=bdPadron;Trusted_Connection=True";
        public static Persona ConsultaPadron(int dni){
            Persona p = null;
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                p = db.QueryFirstOrDefault<Persona>("SELECT * FROM Personas WHERE @Pdni = DNI", new {Pdni = dni});
            }
            return p;
        }
        public static List <Persona> ConsultarPersonas(int id){
            List <Persona> p = null;
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                p = db.Query<Persona>("SELECT * FROM Personas WHERE @Pid = IdEstablecimiento", new {Pid = id}).ToList();
            }
            return p;
        }
        public static PersonaYEstablecimiento ConsultaPersonaYEstablecimiento(int dni){
            PersonaYEstablecimiento p = null;
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                p = db.QueryFirstOrDefault<PersonaYEstablecimiento>("SELECT * FROM Personas INNER JOIN Establecimiento ON Establecimiento.IdEstablecimiento = Personas.IdEstablecimiento WHERE @Pdni = Personas.DNI", new {Pdni = dni});
            }
            return p;
        }
        public static Establecimiento ConsultaEstablecimiento(int idEstablecimiento){
            Establecimiento e = null;
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                e = db.QueryFirstOrDefault<Establecimiento>("SELECT * FROM Establecimiento WHERE @PidEstablecimiento = idEstablecimiento", new {PidEstablecimiento = idEstablecimiento});
            }
            return e;
        }
        public static bool Votar(int dni, int NumeroTramite){
            int a = 0;
            DateTime ahora = DateTime.Now;
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                a = db.Execute("UPDATE Personas SET Voto = 'True', Fecha = @Fecha WHERE @PnumeroTramite = NumeroTramite AND @Pdni = DNI", new{PnumeroTramite = NumeroTramite, Pdni = dni, Fecha = ahora});
            }
            if(a > 0) return true;
            return false;
        }
    }
}