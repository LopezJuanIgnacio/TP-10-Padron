const funcion = e=>{
    let res = grecaptcha.getResponse()
    if(res.length == 0){
        e.preventDefault()
        document.querySelector("#label").classList.remove('d-none')
    }
}
try {
    document.querySelector("#form").onsubmit = funcion  
} catch (error) {}