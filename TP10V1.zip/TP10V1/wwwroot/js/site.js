﻿const h = document.getElementsByTagName('head')[0];
const handleSwitch = e=> {
    localStorage.setItem('Estilos', e.target.checked ? true : false)
    estilizador()
}
const sw = document.querySelector("#switch1")
sw.onchange = handleSwitch
const estilizador = ()=>{
    try {
        h.removeChild(document.getElementById('boot'))
        h.removeChild(document.getElementById('css'))
    } catch (error){}
    let estilos = localStorage.getItem('Estilos')
    let css = document.createElement('link')
    let bootstrap = document.createElement('link')
    bootstrap.id = "boot"
    bootstrap.rel ="stylesheet"
    css.id = "css"
    css.rel ="stylesheet"
    if(estilos == 'false'){
        bootstrap.href ="/lib/bootstrap/dist/css/bootstrap.min.css"
        css.href = "/css/site.css"
        sw.checked = false
    }else if(estilos == 'true'){
        bootstrap.href = "/css/bootstrap.min.css"
        css.href = "/css/site2.css"
        sw.checked = true
    }else{
        localStorage.setItem('Estilos', true)
        estilizador()
    }
    console.log(css, bootstrap)
    h.appendChild(css)
    h.appendChild(bootstrap)
}
estilizador()