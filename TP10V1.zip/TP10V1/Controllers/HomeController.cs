﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TP10.Models;

namespace TP10.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult ConsultaPadron(int dni)
        {
            Persona e = BD.ConsultaPersonaYEstablecimiento(dni);
            if(e is null){
                ViewBag.Error = "DNI no encontrado";
                return View("Index");
            } 
            bool puede = true;
            if(e.Voto == true) puede = false;
            ViewBag.Persona = e;
            ViewBag.Puede = puede; 
            return View("Votar");
        }
        [HttpGet]
        public IActionResult ConsultaEstablecimiento(int id)
        {
            Establecimiento e = BD.ConsultaEstablecimiento(id);
            if(e is null){
                ViewBag.Error = "Establecimiento no encontrado";
                return View("Index");
            }
            ViewBag.Establecimiento = e; 
            ViewBag.Personas = BD.ConsultarPersonas(id);
            return View("Reporte");
        }
        [HttpPost]
        public IActionResult Votar(int dni, int numeroTramite)
        {
            Persona e = BD.ConsultaPersonaYEstablecimiento(dni);
            if(e.NumeroTramite != numeroTramite){
                ViewBag.Puede = true; 
                ViewBag.Persona = e;
                ViewBag.Error = "Numero de tramite incorrecto";
                return View("Votar");
            }
            bool paso = BD.Votar(dni, numeroTramite);
            if(!paso) ViewBag.Error = "Error al votar";
            ViewBag.Error = "Voto realizado efectivamente";
            return View("Index");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
